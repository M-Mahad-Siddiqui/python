from flask import Flask,render_template,request

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')
@app.route('/about')
def about():
    return render_template('about.html')
@app.route('/contact')
def contact():
    return render_template('contact.html')
@app.route('/user')
def user(): 
    return render_template('user.html')
@app.route('/user/<name>')
def user_name(name):
    print(type(name))
    return render_template('user.html',yourname=name)
@app.route('/success',methods=['GET','POST'])
def success():
    if request.method == 'POST':
        data = request.form
        name = data['name']
        course = data['course']
        record = {'name':name,'course':course}
    return render_template('user.html',record=record)
    

    
    

if __name__ == '__main__':
    app.run(debug=True, port=5000)








